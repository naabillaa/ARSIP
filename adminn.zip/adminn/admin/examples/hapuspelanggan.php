<?php
include "config.php"; // Mengimpor file konfigurasi database

// Pastikan parameter kodepelanggan pelanggan tersedia
if (isset($_GET['kodepelanggan'])) {
    // Ambil nilai parameter kodepelanggan dari URL
    $kodepelanggan = $_GET['kodepelanggan'];

    // Buat query SQL untuk menghapus pelanggan berdasarkan kodepelanggan
    $query = "DELETE FROM pelanggan WHERE kodepelanggan = '$kodepelanggan'";
    
    // Eksekusi query penghapusan
    if (mysqli_query($conn, $query)) {
        // Jika penghapusan berhasil, tampilkan pesan sukses dan arahkan kembali ke halaman daftarpelanggan.php
        echo "<script>alert('Pelanggan berhasil dihapus.'); window.location='produk.php';</script>";
    } else {
        // Jika terjadi kesalahan saat menjalankan query, tampilkan pesan kesalahan dan kembalikan pengguna ke halaman sebelumnya
        echo "<script>alert('Error: " . mysqli_error($conn) . "'); window.history.back();</script>";
    }
    
    // Tutup koneksi ke database
    mysqli_close($conn);
} else {
    // Jika parameter kodepelanggan tidak tersedia, tampilkan pesan kesalahan dan kembalikan pengguna ke halaman sebelumnya
    echo "<script>alert('Parameter kodepelanggan pelanggan tidak tersedia.'); window.history.back();</script>";
}
?>
